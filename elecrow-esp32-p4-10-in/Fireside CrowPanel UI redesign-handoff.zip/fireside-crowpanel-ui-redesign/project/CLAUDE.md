# Project conventions

## Canonical palette — TrailCurrent head-unit devices (Fireside, Spotter, etc.)

All device GUI mocks in this project MUST use the exact design-system values from
`/projects/3f896a41-40d6-4cc2-b0f1-9cadc3f7e165/colors_and_type.css`. Never invent
tinted variants (no sage-tinted greys, no darkened status colors).

Light (default): bg #f5f5f5 · card #ffffff · card-hover #f0f0f0 · border #dddddd ·
text #1a1a1a / #4a4a4a / muted #888888 · bar rgba(255,255,255,0.95) · accent #52A441 ·
accent-soft #EDF3EA · glow 0 0 15px rgba(82,164,65,0.3)

Dark: bg #000000 · card #1a1a1a · card-hover #252525 · border #333333 ·
text #ffffff / #aaaaaa / muted #666666 · bar rgba(10,10,10,0.95) · accent #7BC96A ·
glow 0 0 20px rgba(82,164,65,0.5)

Status/domain colors are IDENTICAL in both themes: solar/warning #FFC107 ·
info/fresh/cooling #48E6FE · danger/heating #FF5453 · success #74FE00 ·
grey water #9E9E9E · black water #424242 · slate/neutral values #505050 (light) / #BDBDBD (dark).

Brand icon: `uploads/tc_fireside.svg` (Fireside flame mark).
